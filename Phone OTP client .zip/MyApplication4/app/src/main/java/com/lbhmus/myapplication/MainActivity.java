package com.lbhmus.myapplication;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    private EditText editTextPhoneNumber;
    private EditText editTextOTP;
    private Button buttonRequestOTP;
    private Button buttonVerifyOTP;

    private OTPClient otpClient;
    private DatabaseReference ipAddressRef;
    private TextView textViewIpAddress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextPhoneNumber = findViewById(R.id.editTextPhoneNumber);
        editTextOTP = findViewById(R.id.editTextOTP);
        buttonRequestOTP = findViewById(R.id.buttonRequestOTP);
        buttonVerifyOTP = findViewById(R.id.buttonVerifyOTP);
        textViewIpAddress = findViewById(R.id.textViewIpAddress);

        otpClient = new OTPClient(this);
        // Initialize Firebase Database reference
        DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();
        ipAddressRef = rootRef.child("ip_addresses");

        // Read IP address from Firebase
        readIpAddressFromFirebase();

        buttonRequestOTP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phoneNumber = editTextPhoneNumber.getText().toString();
                if (!phoneNumber.isEmpty()) {
                    otpClient.requestOTP(phoneNumber);
                    editTextOTP.setVisibility(View.VISIBLE);
                    buttonVerifyOTP.setVisibility(View.VISIBLE);
                    buttonRequestOTP.setVisibility(View.GONE);
                    editTextPhoneNumber.setVisibility(View.GONE);

                }
            }
        });

        buttonVerifyOTP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phoneNumber = editTextPhoneNumber.getText().toString();
                String otp = editTextOTP.getText().toString();
                if (!phoneNumber.isEmpty() && !otp.isEmpty()) {
                    otpClient.verifyOTP(phoneNumber, otp);
                }
            }
        });
    }

    private void readIpAddressFromFirebase() {
        ipAddressRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                int count = 0;
                String secondIpAddress = null;
                for (DataSnapshot ipSnapshot : dataSnapshot.getChildren()) {
                    if (count == 1) {
                        secondIpAddress = ipSnapshot.getValue(String.class);
                        break;
                    }
                    count++;
                }
                if (secondIpAddress != null) {
                    textViewIpAddress.setText("Second IP Address: " + secondIpAddress);
                } else {
                    textViewIpAddress.setText("Second IP Address: Not available");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                textViewIpAddress.setText("Failed to retrieve IP address");
            }
        });
    }
}