package com.lbhmus.myapplication;

import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class OTPClient {
    private DatabaseReference ipAddressRef;
    private MainActivity activity;

    public OTPClient(MainActivity activity) {
        this.activity = activity;
        // Initialize Firebase Database reference
        DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();
        ipAddressRef = rootRef.child("ip_addresses");
    }

    // Method to request OTP code from the server
// Method to request OTP code from the server
    public void requestOTP(String phoneNumber) {
        getIpAddressForOTPRequest(phoneNumber); // Get IP address and execute OTP request task
    }

    // Method to verify OTP code with the server
    public void verifyOTP(String phoneNumber, String otp) {
        getIpAddressForOTPVerification(phoneNumber, otp); // Get IP address and execute OTP verification task
    }

    private void getIpAddressForOTPRequest(String phoneNumber) {
        // Read the IP address from Firebase Realtime Database
        ipAddressRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                int count = 0;
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    if (count == 1) {
                        String ipAddress = snapshot.getValue(String.class);
                        if (ipAddress != null) {
                            // Execute the OTP request task with the retrieved IP address
                            new RequestOTPTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, "http://" + ipAddress + ":8080/send-otp?phone=" + phoneNumber);
                            Log.d("IPAddress", "IP Address for OTP Request: " + ipAddress);
                        } else {
                            Log.e("IPAddress", "Failed to retrieve IP address from Firebase for OTP Request");
                        }
                        return;
                    }
                    count++;
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle onCancelled
            }
        });
    }

    private void getIpAddressForOTPVerification(String phoneNumber, String otp) {
        // Read the IP address from Firebase Realtime Database
        ipAddressRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                int count = 0;
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    if (count == 1) {
                        String ipAddress = snapshot.getValue(String.class);
                        if (ipAddress != null) {
                            // Execute the OTP verification task with the retrieved IP address
                            new VerifyOTPTask(activity).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, "http://" + ipAddress + ":8080/verify-otp?phone=" + phoneNumber + "&otp=" + otp);
                            Log.d("IPAddress", "IP Address for OTP Verification: " + ipAddress);
                        } else {
                            Log.e("IPAddress", "Failed to retrieve IP address from Firebase for OTP Verification");
                        }
                        return;
                    }
                    count++;
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle onCancelled
            }
        });
    }
    private static class RequestOTPTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String urlString = params[0];
            try {
                URL url = new URL(urlString);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");

                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;

                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }

                reader.close();
                return stringBuilder.toString();
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                Log.d("RequestOTPTask", result);
                // Handle the response from the server
            } else {
                Log.e("RequestOTPTask", "Failed to request OTP");
            }
        }
    }

    private class VerifyOTPTask extends AsyncTask<String, Void, String> {
        private MainActivity activity;

        public VerifyOTPTask(MainActivity activity) {
            this.activity = activity;
        }

        @Override
        protected String doInBackground(String... params) {
            String urlString = params[0];
            try {
                URL url = new URL(urlString);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");

                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;

                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }

                reader.close();
                return stringBuilder.toString();
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                Log.d("VerifyOTPTask", result);
                // Check if the result indicates successful OTP verification
                // For example, if your server responds with "OTP verification successful"
                if (result.contains("OTP verification successful")) {
                    // If verification is successful, start the new activity
                    Intent intent = new Intent(activity, MainActivity2.class);
                    activity.startActivity(intent);
                    // Finish the current activity if needed
                    activity.finish();
                } else {
                    // Handle other cases if necessary
                }
            } else {
                Log.e("VerifyOTPTask", "Failed to verify OTP");
            }
        }
    }

}
