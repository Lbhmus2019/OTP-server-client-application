package com.lbhmus.phoneotpserver;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.SubscriptionManager;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.koushikdutta.async.AsyncServer;
import com.koushikdutta.async.http.server.AsyncHttpServer;
import com.koushikdutta.async.http.server.AsyncHttpServerRequest;
import com.koushikdutta.async.http.server.AsyncHttpServerResponse;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;

public class MainActivity extends AppCompatActivity {

    private static final int PORT = 8080;
    private static final int REQUEST_CODE_PERMISSION_SEND_SMS = 123;

    private AsyncHttpServer server;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Check and request SMS permission
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, REQUEST_CODE_PERMISSION_SEND_SMS);
        } else {
            // Permission already granted, start the HTTP server
            startHttpServer();
        }

        // Get and log the IP address of the server
        String ipAddress = getLocalIpAddress();
        Log.d("MainActivity", "Server IP address: " + ipAddress);
    }

    private void startHttpServer() {
        server = new AsyncHttpServer();
        server.get("/hello", this::handleHelloRequest);
        server.get("/send-sms", this::handleSendSMSRequest);
        server.listen(AsyncServer.getDefault(), PORT);
        Log.d("MainActivity", "Server started on port " + PORT);
    }

    private void handleHelloRequest(AsyncHttpServerRequest request, AsyncHttpServerResponse response) {
        response.send("Hello, world!");
    }

    private void handleSendSMSRequest(AsyncHttpServerRequest request, AsyncHttpServerResponse response) {
        // Extract recipient phone number and message from the request query parameters
        String phoneNumber = request.getQuery().getString("phone");
        String message = request.getQuery().getString("message");

        // Send SMS
        sendSMS(phoneNumber, message);

        // Respond to the client
        response.send("SMS sent to " + phoneNumber + ": " + message);
    }

    private void sendSMS(String phoneNumber, String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Log.d("MainActivity", "SMS sent to " + phoneNumber + ": " + message);
            // Log the SMS send request
            Log.d("MainActivity", "SMS send request: Phone number: " + phoneNumber + ", Message: " + message);
        } catch (Exception e) {
            Log.e("MainActivity", "Failed to send SMS: " + e.getMessage());
            e.printStackTrace();
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE_PERMISSION_SEND_SMS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, start the HTTP server
                startHttpServer();
            } else {
                // Permission denied, handle accordingly
                Log.e("MainActivity", "SMS permission denied");
                // You may want to inform the user or handle this situation differently
            }
        }
    }

    private String getLocalIpAddress() {
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            while (interfaces.hasMoreElements()) {
                NetworkInterface networkInterface = interfaces.nextElement();
                Enumeration<InetAddress> addresses = networkInterface.getInetAddresses();
                while (addresses.hasMoreElements()) {
                    InetAddress address = addresses.nextElement();
                    if (!address.isLoopbackAddress() && address instanceof Inet4Address) {
                        return address.getHostAddress();
                    }
                }
            }
        } catch (SocketException e) {
            e.printStackTrace();
        }
        return null;
    }
}
